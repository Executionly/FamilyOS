# FamilyOS™ — Mobile App Design Document

## Design Philosophy

**Warm, premium, family-safe aesthetic** — not corporate, not cold. Every screen feels intentional, not scaffolded. Full loading states, empty states, and error states on every screen.

### Color Palette
- **Deep Navy** (#0F172A) — Primary base, headers, strong emphasis
- **Warm Gold** (#F59E0B) — Primary accent, CTAs, highlights
- **Soft Cream** (#FFF8F0) — Background, cards, surfaces
- **White** — Card backgrounds with subtle shadow
- **Neutral Grays** — Text hierarchy, borders, muted elements

### Typography
- **Headings**: Large, confident, family-forward (Plus Jakarta Sans or Inter)
- **Body**: Friendly, readable, warm tone
- **Font Stack**: Expo Google Fonts (Inter or Plus Jakarta Sans)

### Layout Principles
- **Bottom Tab Navigation** (5 tabs): Home, Calendar, Meetings, Legacy, Profile
- **Cards-based layout** throughout — avoid raw lists
- **Responsive to portrait 9:16** — one-handed usage priority
- **Subtle shadows** on cards, no harsh borders
- **Generous whitespace** — premium feel

---

## Screen List & User Flows

### Phase 1 — Foundation (Auth & Onboarding)

#### 1. **Sign In / Sign Up Screen**
- **Content**: Email input, password input, Apple Sign-In button, Google Sign-In button
- **Functionality**: Email/password auth, OAuth (Apple + Google), forgot password link
- **States**: Default, loading, error (invalid credentials), success (redirect to onboarding or home)
- **Design**: Centered card, warm gold CTA button, subtle background gradient

#### 2. **Onboarding Flow**
- **Screen 2a: Welcome** — "Welcome to FamilyOS™" + family name input
- **Screen 2b: Add Members** — Add parent/co-parent, then add children (name, age band)
- **Screen 2c: Invite Co-Parent** — Email invite for co-parent (optional)
- **Screen 2d: Ready to Begin** — Summary of family setup, "Start Foundation Builder" CTA

---

### Phase 2 — Core Value Moment (Foundation Builder)

#### 3. **Foundation Builder (AI-Guided Charter Creation)**
- **Screen 3a: Mission & Vision** — Guided prompts → AI drafts mission/vision → user edits
- **Screen 3b: Core Values** — Guided prompts → AI suggests 8-10 values → user selects/edits
- **Screen 3c: Constitution** — Guided prompts → AI assembles constitution text → user edits
- **Screen 3d: Family Charter Preview** — Full charter display, shareable PDF/image export
- **Design**: Step-by-step card flow, progress indicator, warm gold accent on selections

---

### Phase 3 — Retention Ritual (Weekly Family Meeting OS)

#### 4. **Weekly Family Meeting OS**
- **Screen 4a: Meeting Setup** — Date/time picker, attendee selection, "Start Meeting" CTA
- **Screen 4b: Meeting Agenda** — AI-generated agenda (values + open commitments + wins), full-screen item navigation
- **Screen 4c: Run Meeting Mode** — One item per screen, full-screen immersive mode, capture commitments/notes live
- **Screen 4d: Meeting Summary** — AI-generated summary, decisions, commitments, next steps, shareable

---

### Phase 4 — Operations

#### 5. **Commitments & Accountability**
- **Screen 5a: Commitments List** — Cards showing open/done commitments, assignee, due date
- **Screen 5b: Create Commitment** — Title, assignee, due date, source (meeting/adhoc), notes
- **Screen 5c: Commitment Detail** — Full details, mark done, edit, delete

#### 6. **Shared Calendar & Events**
- **Screen 6a: Calendar View** — Month view with event indicators, tap to see day details
- **Screen 6b: Day View** — List of events for selected day, create event CTA
- **Screen 6c: Create Event** — Title, date/time, location, attendees, recurrence, reminders

#### 7. **Chores & Responsibilities**
- **Screen 7a: Chores List** — Cards showing recurring chores, assignee, due day, status
- **Screen 7b: Create Chore** — Title, assignee, recurrence, due day, verification
- **Screen 7c: Chore Detail** — Full details, mark done, edit, delete

---

### Phase 5 — Intelligence & Legacy

#### 8. **Growth & Character Tracking**
- **Screen 8a: Growth Log** — Cards showing logged growth notes, member, value/trait
- **Screen 8b: Log Growth** — Member selector, value/trait picker, note input, date

#### 9. **Family Culture Analytics**
- **Screen 9a: Culture Dashboard** — Weekly metrics (meeting done, followthrough rate, chore rate), AI insight

#### 10. **Lite Legacy OS**
- **Screen 10a: Memory Vault** — Grid of photos/clips, tap to view, add new
- **Screen 10b: Story Archive** — List of family stories, tap to read, add new
- **Screen 10c: Family Timeline** — Chronological events (memories, stories, milestones)

---

### Phase 6 — AI & Monetization

#### 11. **AI Family Assistant**
- **Screen 11a: Chat Interface** — Message list, input field, grounded in family data only
- **Screen 11b: Chat Detail** — Full conversation, context from Charter/meetings/commitments/calendar/chores/memories

#### 12. **Freemium Gates**
- **Subscription Prompt** — When user hits free tier limit (e.g., 3 AI messages/week, 4 active commitments)
- **Subscription Manager** — View tier, manage billing, upgrade/downgrade

---

### Bottom Tab Navigation (5 Tabs)

1. **Home** — Family overview, recent meetings, upcoming events, quick actions
2. **Calendar** — Month/day view, create events, see commitments
3. **Meetings** — Weekly meeting OS, past meetings, upcoming agenda
4. **Legacy** — Memory Vault, Story Archive, Family Timeline
5. **Profile** — Family settings, member management, billing, logout

---

## Key User Flows

### Flow 1: New Family Setup
1. Sign In (email/OAuth) → Onboarding (family name, add members, invite co-parent) → Foundation Builder (Mission/Vision/Values/Constitution) → Home

### Flow 2: Weekly Family Meeting
1. Home → Meetings tab → "Start Meeting" → AI agenda → Run Meeting Mode (full-screen, one item per screen) → Capture commitments → AI summary → Share

### Flow 3: Daily Life Coordination
1. Home → Calendar → Create event / View commitments / Check chores → Mark done → Culture analytics

### Flow 4: Family Legacy
1. Home → Legacy tab → Memory Vault (add photo) / Story Archive (add story) / Family Timeline (view all)

### Flow 5: AI Family Assistant
1. Any screen → Tap "Ask Assistant" → Chat interface → Get grounded answers → Share insights

---

## Component Hierarchy

```
App
├── Auth Stack (Sign In / Sign Up)
├── Onboarding Stack
├── Main App (Bottom Tab Navigation)
│   ├── Home Tab
│   │   ├── Family Overview Card
│   │   ├── Recent Meetings Card
│   │   ├── Upcoming Events Card
│   │   └── Quick Actions
│   ├── Calendar Tab
│   │   ├── Month View
│   │   ├── Day View
│   │   └── Event Detail
│   ├── Meetings Tab
│   │   ├── Weekly Meeting Setup
│   │   ├── Meeting Agenda
│   │   ├── Run Meeting Mode
│   │   └── Meeting Summary
│   ├── Legacy Tab
│   │   ├── Memory Vault
│   │   ├── Story Archive
│   │   └── Family Timeline
│   └── Profile Tab
│       ├── Family Settings
│       ├── Member Management
│       ├── Billing
│       └── Logout
└── Modals
    ├── AI Family Assistant Chat
    ├── Subscription Prompt
    └── Freemium Gates
```

---

## Loading, Empty, and Error States

### Loading State
- Skeleton cards with shimmer animation
- Placeholder text with reduced opacity
- Spinner overlay for async operations

### Empty State
- Friendly illustration or icon
- Clear message ("No meetings yet", "No events scheduled")
- CTA to create first item

### Error State
- Red/warning color accent
- Clear error message
- Retry button
- Contact support link if critical

---

## Accessibility & Localization

- **Dynamic Type Support**: Text scales with system font size
- **Sufficient Contrast**: WCAG AA minimum (4.5:1 for text)
- **Screen Reader Labels**: All interactive elements have labels
- **Localization-Ready**: All strings externalized (US + Nigeria/Africa target markets)

---

## Design Tokens (Tailwind Config)

| Token | Light | Dark |
|-------|-------|------|
| `primary` | #F59E0B | #F59E0B |
| `background` | #FFF8F0 | #0F172A |
| `surface` | #FFFFFF | #1A1F2E |
| `foreground` | #0F172A | #FFF8F0 |
| `muted` | #6B7280 | #9CA3AF |
| `border` | #E5E7EB | #2D3748 |
| `success` | #10B981 | #10B981 |
| `warning` | #F59E0B | #F59E0B |
| `error` | #EF4444 | #EF4444 |

---

## Next Steps

1. Confirm this design direction with product owner
2. Build Phase 1 (Auth + Onboarding)
3. Build Phase 2 (Foundation Builder)
4. Build Phase 3 (Weekly Meeting OS)
5. Continue with remaining phases

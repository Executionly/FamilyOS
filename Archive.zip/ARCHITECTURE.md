# FamilyOS™ — Complete Architecture Overview

## Executive Summary

FamilyOS™ is an AI-powered Family Operating System built with **React Native + Expo** on the client side and **Supabase** on the backend. The architecture enforces strict Row-Level Security (RLS) at the database layer, server-side AI calls via DeepSeek, and offline-first reads via Zustand + AsyncStorage.

---

## Technology Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Client** | React Native 0.81 + Expo 54 | Cross-platform mobile (iOS/Android/Web) |
| **Navigation** | Expo Router 6 | File-based routing, bottom tab navigation |
| **State Management** | Zustand | Global state, offline persistence via AsyncStorage |
| **Styling** | NativeWind 4 (Tailwind CSS) | Consistent theming, responsive design |
| **Backend** | Supabase (PostgreSQL + Auth) | Database, authentication, RLS, Realtime, Storage |
| **AI Provider** | DeepSeek API | Server-side LLM calls (never exposed to client) |
| **Push Notifications** | Expo Notifications (APNs + FCM) | Local and remote notifications |
| **Payments** | RevenueCat | In-app subscriptions (StoreKit + Google Play Billing) |
| **Analytics** | PostHog | Event tracking and user insights |
| **Payments Verification** | Supabase Edge Functions | Webhook verification for RevenueCat |

---

## Project Structure

```
/home/ubuntu/family-os/
├── app/
│   ├── _layout.tsx                 # Root layout, providers (Auth, Theme, Zustand)
│   ├── oauth/
│   │   └── callback.tsx            # OAuth redirect handler
│   ├── (auth)/
│   │   ├── _layout.tsx             # Auth stack layout
│   │   ├── sign-in.tsx             # Sign In screen (email + OAuth)
│   │   ├── sign-up.tsx             # Sign Up screen
│   │   └── forgot-password.tsx     # Forgot password flow
│   ├── (onboarding)/
│   │   ├── _layout.tsx             # Onboarding stack layout
│   │   ├── welcome.tsx             # Family name input
│   │   ├── add-members.tsx         # Add parent/co-parent + children
│   │   ├── invite-coparent.tsx     # Invite co-parent email
│   │   └── ready.tsx               # Onboarding complete
│   ├── (tabs)/
│   │   ├── _layout.tsx             # Tab bar layout (5 tabs)
│   │   ├── index.tsx               # Home tab
│   │   ├── calendar.tsx            # Calendar tab
│   │   ├── meetings.tsx            # Meetings tab
│   │   ├── legacy.tsx              # Legacy tab
│   │   └── profile.tsx             # Profile tab
│   ├── (modals)/
│   │   ├── foundation-builder.tsx  # Foundation Builder flow (Mission/Vision/Values/Constitution)
│   │   ├── meeting-setup.tsx       # Weekly meeting setup
│   │   ├── run-meeting.tsx         # Run meeting mode (full-screen)
│   │   ├── create-commitment.tsx   # Create commitment modal
│   │   ├── create-event.tsx        # Create calendar event modal
│   │   ├── create-chore.tsx        # Create chore modal
│   │   ├── ai-assistant.tsx        # AI Family Assistant chat modal
│   │   ├── subscription.tsx        # Subscription manager modal
│   │   └── freemium-gate.tsx       # Freemium upgrade prompt
│   └── dev/
│       └── theme-lab.tsx           # Theme testing screen
├── components/
│   ├── screen-container.tsx        # SafeArea wrapper for all screens
│   ├── themed-view.tsx             # View with auto theme background
│   ├── haptic-tab.tsx              # Tab bar with haptic feedback
│   ├── ui/
│   │   ├── icon-symbol.tsx         # Icon mapping (SF Symbols → Material Icons)
│   │   ├── card.tsx                # Reusable card component
│   │   ├── button.tsx              # Primary/secondary buttons
│   │   ├── input.tsx               # Text input with validation
│   │   ├── modal.tsx               # Modal wrapper
│   │   ├── loading-skeleton.tsx    # Skeleton loader
│   │   ├── empty-state.tsx         # Empty state component
│   │   └── error-boundary.tsx      # Error boundary
│   └── features/
│       ├── auth/
│       │   ├── sign-in-form.tsx
│       │   ├── sign-up-form.tsx
│       │   └── oauth-buttons.tsx
│       ├── foundation-builder/
│       │   ├── mission-vision-step.tsx
│       │   ├── values-step.tsx
│       │   ├── constitution-step.tsx
│       │   └── charter-preview.tsx
│       ├── meetings/
│       │   ├── agenda-screen.tsx
│       │   ├── meeting-item.tsx
│       │   └── meeting-summary.tsx
│       ├── commitments/
│       │   ├── commitment-list.tsx
│       │   ├── commitment-card.tsx
│       │   └── commitment-form.tsx
│       ├── calendar/
│       │   ├── calendar-month-view.tsx
│       │   ├── calendar-day-view.tsx
│       │   └── event-card.tsx
│       ├── chores/
│       │   ├── chore-list.tsx
│       │   ├── chore-card.tsx
│       │   └── chore-form.tsx
│       ├── legacy/
│       │   ├── memory-vault.tsx
│       │   ├── story-archive.tsx
│       │   └── family-timeline.tsx
│       └── ai-assistant/
│           ├── chat-interface.tsx
│           └── message-list.tsx
├── hooks/
│   ├── use-auth.ts                 # Auth state hook
│   ├── use-colors.ts               # Theme colors hook
│   ├── use-color-scheme.ts         # Dark/light mode detection
│   ├── use-family.ts               # Family data hook (Zustand)
│   ├── use-charter.ts              # Charter data hook (Zustand)
│   ├── use-meetings.ts             # Meetings data hook (Zustand)
│   ├── use-commitments.ts          # Commitments data hook (Zustand)
│   ├── use-calendar.ts             # Calendar data hook (Zustand)
│   ├── use-chores.ts               # Chores data hook (Zustand)
│   ├── use-growth.ts               # Growth tracking hook (Zustand)
│   ├── use-culture.ts              # Culture metrics hook (Zustand)
│   ├── use-memories.ts             # Memories hook (Zustand)
│   ├── use-stories.ts              # Stories hook (Zustand)
│   ├── use-subscription.ts         # Subscription status hook (Zustand)
│   └── use-ai-assistant.ts         # AI assistant hook (Zustand)
├── lib/
│   ├── _core/
│   │   ├── theme.ts                # Runtime theme palette builder
│   │   ├── auth.ts                 # Supabase Auth client
│   │   ├── supabase.ts             # Supabase client initialization
│   │   ├── api.ts                  # API client (tRPC)
│   │   └── nativewind-pressable.ts # NativeWind Pressable fix
│   ├── theme-provider.tsx          # Global theme context
│   ├── utils.ts                    # Utility functions (cn, etc.)
│   ├── stores/
│   │   ├── family-store.ts         # Zustand family store
│   │   ├── charter-store.ts        # Zustand charter store
│   │   ├── meetings-store.ts       # Zustand meetings store
│   │   ├── commitments-store.ts    # Zustand commitments store
│   │   ├── calendar-store.ts       # Zustand calendar store
│   │   ├── chores-store.ts         # Zustand chores store
│   │   ├── growth-store.ts         # Zustand growth store
│   │   ├── culture-store.ts        # Zustand culture store
│   │   ├── memories-store.ts       # Zustand memories store
│   │   ├── stories-store.ts        # Zustand stories store
│   │   ├── subscription-store.ts   # Zustand subscription store
│   │   └── ai-assistant-store.ts   # Zustand AI assistant store
│   ├── services/
│   │   ├── auth-service.ts         # Auth API calls
│   │   ├── family-service.ts       # Family API calls
│   │   ├── charter-service.ts      # Charter API calls
│   │   ├── meeting-service.ts      # Meeting API calls
│   │   ├── commitment-service.ts   # Commitment API calls
│   │   ├── calendar-service.ts     # Calendar API calls
│   │   ├── chore-service.ts        # Chore API calls
│   │   ├── growth-service.ts       # Growth API calls
│   │   ├── culture-service.ts      # Culture API calls
│   │   ├── memory-service.ts       # Memory API calls
│   │   ├── story-service.ts        # Story API calls
│   │   ├── ai-service.ts           # AI assistant API calls
│   │   └── subscription-service.ts # Subscription API calls
│   └── validators/
│       ├── auth-validators.ts
│       ├── family-validators.ts
│       ├── charter-validators.ts
│       └── ... (other validators)
├── constants/
│   ├── theme.ts                    # Theme color constants
│   ├── oauth.ts                    # OAuth config
│   └── const.ts                    # App constants
├── server/
│   ├── _core/
│   │   ├── index.ts                # Express server entry
│   │   ├── context.ts              # tRPC context
│   │   ├── trpc.ts                 # tRPC router setup
│   │   ├── auth.ts                 # Auth middleware
│   │   ├── supabase.ts             # Supabase client (server-side)
│   │   ├── llm.ts                  # DeepSeek LLM wrapper
│   │   ├── notification.ts         # Push notification service
│   │   ├── storage.ts              # File storage service
│   │   └── env.ts                  # Environment variables
│   ├── routers/
│   │   ├── auth.ts                 # Auth router
│   │   ├── family.ts               # Family router
│   │   ├── charter.ts              # Charter router
│   │   ├── meetings.ts             # Meetings router
│   │   ├── commitments.ts          # Commitments router
│   │   ├── calendar.ts             # Calendar router
│   │   ├── chores.ts               # Chores router
│   │   ├── growth.ts               # Growth router
│   │   ├── culture.ts              # Culture router
│   │   ├── memories.ts             # Memories router
│   │   ├── stories.ts              # Stories router
│   │   ├── ai-assistant.ts         # AI assistant router
│   │   └── subscription.ts         # Subscription router
│   └── supabase-functions/
│       ├── ai-service/
│       │   └── index.ts            # Wraps DeepSeek API
│       ├── generate-agenda/
│       │   └── index.ts            # AI agenda generation
│       ├── generate-charter/
│       │   └── index.ts            # AI charter assembly
│       ├── generate-summary/
│       │   └── index.ts            # AI meeting summary
│       ├── culture-insight/
│       │   └── index.ts            # AI culture insight
│       ├── family-assistant/
│       │   └── index.ts            # Grounded AI chat
│       ├── revenuecat-webhook/
│       │   └── index.ts            # RevenueCat webhook handler
│       ├── send-push/
│       │   └── index.ts            # Push notification sender
│       └── schedule-nudges/
│           └── index.ts            # Nudge scheduler (pg_cron)
├── shared/
│   ├── types/
│   │   ├── family.ts               # Family types
│   │   ├── charter.ts              # Charter types
│   │   ├── meetings.ts             # Meeting types
│   │   ├── commitments.ts          # Commitment types
│   │   ├── calendar.ts             # Calendar types
│   │   ├── chores.ts               # Chore types
│   │   ├── growth.ts               # Growth types
│   │   ├── culture.ts              # Culture types
│   │   ├── memories.ts             # Memory types
│   │   ├── stories.ts              # Story types
│   │   ├── subscription.ts         # Subscription types
│   │   └── ai.ts                   # AI types
│   └── validators/
│       ├── family.ts               # Family Zod schemas
│       ├── charter.ts              # Charter Zod schemas
│       └── ... (other schemas)
├── assets/
│   └── images/
│       ├── icon.png                # App icon (to be generated)
│       ├── splash-icon.png         # Splash screen icon
│       ├── favicon.png             # Web favicon
│       ├── android-icon-foreground.png
│       ├── android-icon-background.png
│       └── android-icon-monochrome.png
├── tests/
│   ├── auth.test.ts
│   ├── family.test.ts
│   ├── charter.test.ts
│   └── ... (other tests)
├── app.config.ts                   # Expo config
├── tailwind.config.js              # Tailwind configuration
├── theme.config.js                 # Theme tokens
├── tsconfig.json                   # TypeScript config
├── package.json                    # Dependencies
├── design.md                        # Design document
├── ARCHITECTURE.md                 # This file
└── todo.md                          # Feature tracking
```

---

## Data Flow Architecture

### 1. Client → Server → Supabase → DeepSeek (AI Flow)

```
Screen Component
    ↓
Zustand Store (dispatch action)
    ↓
Service Layer (call tRPC router)
    ↓
tRPC Router (server-side)
    ↓
Supabase Edge Function (ai-service)
    ↓
DeepSeek API (LLM call)
    ↓
Edge Function returns response
    ↓
tRPC Router returns to client
    ↓
Zustand Store (update state)
    ↓
Screen Component (re-render)
```

### 2. Client → Supabase (Direct Data Sync)

```
Screen Component
    ↓
Zustand Store (dispatch action)
    ↓
Service Layer (call tRPC router)
    ↓
tRPC Router (server-side)
    ↓
Supabase Client (INSERT/UPDATE/DELETE)
    ↓
Supabase RLS Policy (verify family_id)
    ↓
PostgreSQL (execute query)
    ↓
Supabase Realtime (broadcast to other clients)
    ↓
Zustand Store (update state)
    ↓
Screen Component (re-render)
```

### 3. Offline-First Read Flow

```
Screen Component
    ↓
Zustand Store (check local state first)
    ↓
If data exists in AsyncStorage → use it (offline)
    ↓
If data missing → fetch from Supabase
    ↓
Zustand Store (save to AsyncStorage)
    ↓
Screen Component (re-render)
    ↓
On reconnect → sync any pending changes
```

---

## Zustand Store Architecture

Each domain has its own Zustand store with the following pattern:

```typescript
// lib/stores/[domain]-store.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface [Domain]State {
  // Data
  data: [Domain][];
  loading: boolean;
  error: string | null;
  
  // Actions
  fetchData: () => Promise<void>;
  createItem: (item: [Domain]) => Promise<void>;
  updateItem: (id: string, updates: Partial<[Domain]>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  setError: (error: string | null) => void;
}

export const use[Domain]Store = create<[Domain]State>()(
  persist(
    (set, get) => ({
      data: [],
      loading: false,
      error: null,
      
      fetchData: async () => {
        set({ loading: true });
        try {
          const response = await [domain]Service.fetch();
          set({ data: response, error: null });
        } catch (error) {
          set({ error: error.message });
        } finally {
          set({ loading: false });
        }
      },
      
      // ... other actions
    }),
    {
      name: '[domain]-storage',
      storage: AsyncStorage,
    }
  )
);
```

### Zustand Stores by Domain

1. **Family Store** — Family data, members, roles
2. **Charter Store** — Mission, vision, values, constitution
3. **Meetings Store** — Meetings, agendas, summaries
4. **Commitments Store** — Open/done commitments
5. **Calendar Store** — Events, recurrence, reminders
6. **Chores Store** — Recurring chores, assignments
7. **Growth Store** — Growth logs, traits
8. **Culture Store** — Weekly metrics, insights
9. **Memories Store** — Photos, clips, captions
10. **Stories Store** — Family stories, tags
11. **Subscription Store** — Tier, status, limits
12. **AI Assistant Store** — Chat messages, context

---

## Supabase Database Schema

### Core Tables (All with RLS)

```sql
-- Family (root entity)
CREATE TABLE family (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  photo_url TEXT,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  subscription_status TEXT DEFAULT 'free',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Member (family member, child or parent)
CREATE TABLE member (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'coparent', 'member', 'child')),
  age_band TEXT,
  has_login BOOLEAN DEFAULT false,
  user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Charter (Family Mission, Vision, Values, Constitution)
CREATE TABLE charter (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  mission TEXT,
  vision TEXT,
  values JSONB DEFAULT '[]',
  constitution_items JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Meeting (Weekly family meeting)
CREATE TABLE meeting (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  date TIMESTAMP NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('scheduled', 'in_progress', 'completed')),
  agenda_json JSONB,
  summary TEXT,
  created_by UUID NOT NULL REFERENCES member(id),
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Commitment (Action items from meetings or adhoc)
CREATE TABLE commitment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  assignee_member_id UUID NOT NULL REFERENCES member(id),
  due_date TIMESTAMP,
  status TEXT NOT NULL CHECK (status IN ('open', 'done')) DEFAULT 'open',
  source TEXT CHECK (source IN ('meeting', 'adhoc')),
  meeting_id UUID REFERENCES meeting(id),
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- CalendarEvent (Shared family events)
CREATE TABLE calendar_event (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  start TIMESTAMP NOT NULL,
  end TIMESTAMP,
  location TEXT,
  attendees JSONB DEFAULT '[]',
  recurrence TEXT,
  reminder BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- Chore (Recurring responsibilities)
CREATE TABLE chore (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  assignee_member_id UUID NOT NULL REFERENCES member(id),
  recurrence TEXT NOT NULL,
  due_day INTEGER,
  status TEXT NOT NULL CHECK (status IN ('open', 'done')) DEFAULT 'open',
  verified_by UUID REFERENCES member(id),
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- GrowthLog (Character tracking)
CREATE TABLE growth_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES member(id),
  value_or_trait TEXT NOT NULL,
  note TEXT,
  logged_at TIMESTAMP DEFAULT now()
);

-- CultureMetric (Weekly family metrics)
CREATE TABLE culture_metric (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  week DATE NOT NULL,
  meeting_done BOOLEAN DEFAULT false,
  followthrough_rate FLOAT,
  chore_rate FLOAT,
  engagement_json JSONB,
  created_at TIMESTAMP DEFAULT now()
);

-- Memory (Photos, clips, notes)
CREATE TABLE memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('photo', 'clip', 'note')),
  media_url TEXT,
  caption TEXT,
  member_tags JSONB DEFAULT '[]',
  event_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);

-- Story (Family narratives)
CREATE TABLE story (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  member_tags JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- TimelineEvent (Chronological events)
CREATE TABLE timeline_event (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  ref_type TEXT NOT NULL CHECK (ref_type IN ('memory', 'story', 'milestone')),
  ref_id UUID NOT NULL,
  date TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

-- Nudge (Scheduled reminders)
CREATE TABLE nudge (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  payload JSONB,
  scheduled_for TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

-- Subscription (RevenueCat integration)
CREATE TABLE subscription (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id UUID NOT NULL REFERENCES family(id) ON DELETE CASCADE,
  tier TEXT NOT NULL CHECK (tier IN ('free', 'premium')) DEFAULT 'free',
  provider TEXT,
  status TEXT,
  renews_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
```

### RLS Policies (All Tables)

Every table has RLS policies that:
1. Verify the user belongs to the family
2. Scope all queries to `family_id`
3. Prevent cross-family data access

Example policy:
```sql
CREATE POLICY "Users can only access their family's data"
  ON charter FOR SELECT
  USING (
    family_id = (
      SELECT family_id FROM member
      WHERE user_id = auth.uid()
      LIMIT 1
    )
  );
```

---

## Supabase Edge Functions

### 1. `ai-service` — Wraps DeepSeek

```typescript
// supabase/functions/ai-service/index.ts
export async function aiService(
  type: 'mission-vision' | 'values' | 'constitution' | 'agenda' | 'summary' | 'culture-insight' | 'story-prompt' | 'chat',
  context: Record<string, any>
): Promise<string> {
  // Call DeepSeek API with appropriate prompt
  // Return streamed or complete response
}
```

### 2. `generate-agenda` — AI Meeting Agenda

Pulls family charter values, open commitments, recent wins, then calls `ai-service` to generate personalized agenda.

### 3. `generate-charter` — AI Charter Assembly

Assembles charter from Foundation Builder answers (mission, vision, values, constitution) and calls `ai-service`.

### 4. `generate-summary` — AI Meeting Summary

Summarizes captured meeting data (agenda, commitments, notes) and calls `ai-service`.

### 5. `culture-insight` — Weekly AI Insight

Analyzes weekly metrics (meeting done, followthrough rate, chore rate) and generates AI insight.

### 6. `family-assistant` — Grounded AI Chat

Pulls full family context (charter, meetings, commitments, calendar, chores, memories) and answers user queries via `ai-service`. Rate-limits free tier (3 msgs/week).

### 7. `revenuecat-webhook` — RevenueCat Verification

Verifies RevenueCat webhook signature, updates `subscription` table with new tier/status.

### 8. `send-push` — Push Notifications

Sends Expo push notifications via APNs (iOS) and FCM (Android).

### 9. `schedule-nudges` — pg_cron Triggered

Scheduled job that fires nudges (e.g., "Weekly meeting reminder") at specified times.

---

## Authentication Flow

### 1. Email + Password
```
Sign In/Sign Up Screen
  ↓
Supabase Auth (email + password)
  ↓
JWT token stored in secure storage (expo-secure-store)
  ↓
Zustand auth store updated
  ↓
Redirect to onboarding or home
```

### 2. Apple Sign-In
```
Sign In Screen → Apple Sign-In button
  ↓
Supabase Auth (Apple OAuth)
  ↓
JWT token stored in secure storage
  ↓
Zustand auth store updated
  ↓
Redirect to onboarding or home
```

### 3. Google Sign-In
```
Sign In Screen → Google Sign-In button
  ↓
Supabase Auth (Google OAuth)
  ↓
JWT token stored in secure storage
  ↓
Zustand auth store updated
  ↓
Redirect to onboarding or home
```

---

## State Management Flow

### Example: Fetching Commitments

```
1. User opens Commitments screen
2. Component calls useCommitments() hook
3. Hook returns commitments store state
4. If data is empty and not loading:
   - Call commitmentService.fetchCommitments()
   - Service calls tRPC router
   - Router queries Supabase (RLS enforces family_id)
   - Store updates with fetched data
   - Data persisted to AsyncStorage
5. Component renders commitments list
6. On reconnect (if offline):
   - Sync any pending changes
   - Refresh data from server
```

---

## Offline-First Strategy

### Read Operations (Offline-Capable)
- Charter
- Calendar events
- Open commitments
- Chores
- Memories
- Stories

### Write Operations (Sync on Reconnect)
- Create/update/delete commitments
- Create/update/delete events
- Mark chores done
- Add memories/stories

### Implementation
1. All reads check AsyncStorage first
2. If data exists, use it (even if offline)
3. If data missing, fetch from Supabase
4. On reconnect, sync pending writes
5. Zustand + AsyncStorage handles persistence

---

## Error Handling Strategy

### Client-Side Errors
- Network errors → Show "No internet" message, offer retry
- Validation errors → Show field-level error messages
- API errors → Show error boundary with retry option
- Auth errors → Redirect to sign-in

### Server-Side Errors
- 400 Bad Request → Show validation error message
- 401 Unauthorized → Redirect to sign-in
- 403 Forbidden → Show "Access denied" (RLS violation)
- 500 Internal Server Error → Show error boundary with retry

### Error Boundary Component
```typescript
<ErrorBoundary
  onError={(error) => {
    console.error(error);
    showErrorToast(error.message);
  }}
  onReset={() => {
    // Retry logic
  }}
>
  <YourComponent />
</ErrorBoundary>
```

---

## Performance Optimization

### 1. Code Splitting
- Lazy load modals and screens via Expo Router
- Dynamic imports for heavy components

### 2. List Optimization
- Use FlatList (never ScrollView with .map())
- Implement virtualization for long lists
- Memoize list item components

### 3. Image Optimization
- Compress media client-side before upload
- Use Expo Image with caching
- Lazy-load images in memory vault

### 4. State Optimization
- Zustand selectors return stable references
- Memoize derived data with useMemo
- Avoid unnecessary re-renders with React.memo

### 5. API Optimization
- Batch requests where possible
- Implement request debouncing
- Cache responses in AsyncStorage

### Target Performance
- Home, Calendar, Meeting screens < 1.5s load on mid-range devices
- AI responses stream where possible
- Smooth 60 FPS animations

---

## Accessibility & Localization

### Accessibility
- Dynamic Type support (text scales with system font size)
- Sufficient contrast ratios (WCAG AA minimum 4.5:1)
- Screen reader labels on all interactive elements
- Keyboard navigation support

### Localization
- All strings externalized to constants
- Support US English + Nigerian/African languages
- RTL support (if needed)
- Date/time formatting by locale

---

## Deployment & Monitoring

### Development
- Local Expo dev server (Metro bundler)
- Supabase local development (optional)
- Hot reload on code changes

### Production
- EAS Build for iOS/Android builds
- Supabase production instance
- PostHog analytics
- Error tracking (Sentry or similar)

### Monitoring
- Performance metrics (load times, API latency)
- Error tracking (crashes, API errors)
- User analytics (feature usage, retention)
- Subscription metrics (conversion, churn)

---

## Next Steps

1. **Confirm this architecture** with product owner
2. **Build Phase 1** (Auth + Onboarding)
3. **Build Phase 2** (Foundation Builder)
4. Continue with remaining phases

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Zustand over Redux** | Simpler API, less boilerplate, perfect for offline-first |
| **Supabase over custom backend** | RLS at database layer, built-in auth, Realtime, Edge Functions |
| **DeepSeek server-side** | Never expose API key to client, full control over prompts |
| **AsyncStorage for offline** | Simple, reliable, sufficient for FamilyOS use case |
| **Bottom tab navigation** | iOS standard, easy one-handed access |
| **Cards-based layout** | Premium feel, clear content hierarchy |
| **No NestJS** | Supabase Edge Functions sufficient for AI calls |
| **RevenueCat over Stripe** | Native in-app purchase support, automatic receipt verification |

---

## Questions & Clarifications

- **Child accounts (under 13)**: No independent login in V1 — parents manage profiles
- **Offline sync**: Pending writes sync on reconnect; reads work offline
- **AI streaming**: Implement where possible (charter generation, meeting summary)
- **Media storage**: Compressed client-side, stored in Supabase Storage (family_id bucket)
- **Realtime sync**: Calendar and commitments sync in real-time across family members

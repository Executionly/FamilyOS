# FamilyOS™ Project TODO

## Phase 1 — Foundation (Auth & Onboarding)

### Auth System
- [x] Sign In screen (email + password)
- [x] Sign Up screen (email + password)
- [ ] Apple Sign-In integration (OAuth setup)
- [ ] Google Sign-In integration (OAuth setup)
- [x] Forgot password flow
- [x] Auth state management (Zustand)
- [x] Secure token storage (expo-secure-store)
- [x] Session persistence

### Onboarding Flow
- [x] Welcome screen (family name input)
- [x] Add Members screen (parent/co-parent + children)
- [x] Invite Co-Parent screen (email invite)
- [x] Onboarding completion screen
- [x] Onboarding state management

### Database & Backend
- [ ] Supabase project setup (manual)
- [x] Family table + RLS policies (migration created)
- [x] Member table + RLS policies (migration created)
- [x] User authentication via Supabase Auth
- [x] Row-Level Security (RLS) on all tables
- [ ] Run database migrations in Supabase

---

## Phase 2 — Core Value Moment (Foundation Builder)

### Foundation Builder Screens
- [x] Mission & Vision screen (guided prompts + AI draft)
- [x] Core Values screen (guided prompts + AI suggestions)
- [x] Constitution screen (guided prompts + AI assembly)
- [x] Family Charter preview screen
- [ ] Charter export (PDF/image)

### AI Integration
- [ ] Supabase Edge Function: `ai-service` (wraps DeepSeek)
- [ ] Supabase Edge Function: `generate-charter`
- [ ] DeepSeek API integration (server-side only)
- [x] Charter table + RLS policies (migration created)
- [ ] Streaming AI responses

### State Management
- [x] Foundation Builder state (Zustand)
- [x] Charter persistence (local + cloud sync)
- [x] Offline-first charter reads

---

## Phase 3 — Retention Ritual (Weekly Family Meeting OS)

### Meeting Screens
- [ ] Meeting setup screen (date/time, attendees)
- [ ] Meeting agenda screen (AI-generated)
- [ ] Run Meeting Mode (full-screen, one item per screen)
- [ ] Commitment capture (live during meeting)
- [ ] Meeting summary screen (AI-generated)

### AI Integration
- [ ] Supabase Edge Function: `generate-agenda`
- [ ] Supabase Edge Function: `generate-summary`
- [ ] Meeting table + RLS policies
- [ ] Streaming agenda generation
- [ ] Streaming summary generation

### State Management
- [ ] Meeting state (Zustand)
- [ ] Commitment capture during meeting
- [ ] Meeting persistence (local + cloud sync)

---

## Phase 4 — Operations

### Commitments & Accountability
- [ ] Commitments list screen
- [ ] Create commitment screen
- [ ] Commitment detail screen
- [ ] Mark commitment done
- [ ] Edit/delete commitment
- [ ] Commitment table + RLS policies
- [ ] Commitment state management

### Shared Calendar & Events
- [ ] Calendar month view
- [ ] Calendar day view
- [ ] Create event screen
- [ ] Event detail screen
- [ ] Edit/delete event
- [ ] Recurrence support
- [ ] Reminders
- [ ] CalendarEvent table + RLS policies
- [ ] Calendar state management
- [ ] Realtime sync (Supabase Realtime)

### Chores & Responsibilities
- [ ] Chores list screen
- [ ] Create chore screen
- [ ] Chore detail screen
- [ ] Mark chore done
- [ ] Edit/delete chore
- [ ] Chore verification
- [ ] Chore table + RLS policies
- [ ] Chore state management

---

## Phase 5 — Intelligence & Legacy

### Growth & Character Tracking
- [ ] Growth log screen
- [ ] Log growth note screen
- [ ] Growth log table + RLS policies
- [ ] Growth state management

### Family Culture Analytics
- [ ] Culture dashboard screen
- [ ] Weekly metrics calculation
- [ ] AI culture insight generation
- [ ] CultureMetric table + RLS policies
- [ ] Supabase Edge Function: `culture-insight`

### Lite Legacy OS
- [ ] Memory Vault screen (photo grid)
- [ ] Add memory screen (photo/clip upload)
- [ ] Story Archive screen (story list)
- [ ] Add story screen
- [ ] Family Timeline screen
- [ ] Memory table + RLS policies
- [ ] Story table + RLS policies
- [ ] TimelineEvent table + RLS policies
- [ ] Media compression (client-side)
- [ ] Media upload to Supabase Storage
- [ ] Lazy-loading media

---

## Phase 6 — AI & Monetization

### AI Family Assistant
- [ ] Chat interface screen
- [ ] Message list
- [ ] Input field
- [ ] Grounded chat (Charter + meetings + commitments + calendar + chores + memories)
- [ ] Rate limiting (free tier: 3 msgs/week)
- [ ] Supabase Edge Function: `family-assistant`
- [ ] Chat state management

### Freemium Gates
- [ ] RevenueCat integration
- [ ] Subscription table + RLS policies
- [ ] Freemium gate logic (commitments, meetings, AI messages, legacy storage)
- [ ] Subscription prompt modal
- [ ] Subscription manager screen
- [ ] Supabase Edge Function: `revenuecat-webhook`

### Monetization Features
- [ ] Premium tier gating
- [ ] Free tier limits
- [ ] Subscription status display
- [ ] Upgrade/downgrade flow

---

## Supabase Edge Functions (All Phases)

- [ ] `ai-service` — wraps DeepSeek, accepts `{ type, context }`
- [ ] `generate-agenda` — pulls values + open commitments + wins, calls ai-service
- [ ] `generate-charter` — assembles Charter from Foundation Builder answers
- [ ] `generate-summary` — summarizes a completed meeting
- [ ] `culture-insight` — generates weekly AI insight from CultureMetric data
- [ ] `family-assistant` — grounded chat, pulls full family context, rate-limits free tier
- [ ] `revenuecat-webhook` — verifies receipt, updates Subscription table
- [ ] `send-push` — sends Expo push notifications via APNs/FCM
- [ ] `schedule-nudges` — pg_cron triggered, fires scheduled nudges

---

## Database Schema & Migrations

- [ ] Family table + RLS
- [ ] Member table + RLS
- [ ] Charter table + RLS
- [ ] Meeting table + RLS
- [ ] Commitment table + RLS
- [ ] CalendarEvent table + RLS
- [ ] Chore table + RLS
- [ ] GrowthLog table + RLS
- [ ] CultureMetric table + RLS
- [ ] Memory table + RLS
- [ ] Story table + RLS
- [ ] TimelineEvent table + RLS
- [ ] Nudge table + RLS
- [ ] Subscription table + RLS

---

## Architecture & Infrastructure

- [ ] Zustand store setup (family, members, charter, meetings, commitments, calendar, chores, growth, culture, memories, stories, timeline, subscription)
- [ ] Supabase client initialization
- [ ] Supabase Auth setup (email + Apple + Google OAuth)
- [ ] Supabase Realtime subscriptions
- [ ] Supabase Storage setup (media bucket)
- [ ] Offline-first state persistence (AsyncStorage)
- [ ] Error handling & logging
- [ ] API error boundaries
- [ ] Loading states on all screens
- [ ] Empty states on all screens
- [ ] Error states on all screens

---

## UI/UX & Polish

- [ ] Theming (warm gold, deep navy, soft cream)
- [ ] Bottom tab navigation (5 tabs)
- [ ] Cards-based layout
- [ ] Responsive design (portrait 9:16)
- [ ] Haptic feedback on interactions
- [ ] Loading animations (skeleton cards, shimmer)
- [ ] Transition animations (subtle, not bouncy)
- [ ] Dark mode support
- [ ] Accessibility (contrast, labels, dynamic type)
- [ ] Localization strings (US + Nigeria/Africa)

---

## Testing & QA

- [ ] Unit tests (Vitest)
- [ ] Integration tests (auth, data sync)
- [ ] End-to-end user flows
- [ ] Offline functionality
- [ ] Performance testing (< 1.5s load on mid-range devices)
- [ ] Accessibility testing
- [ ] iOS build & testing
- [ ] Android build & testing
- [ ] Web testing

---

## Branding & Assets

- [ ] App logo generation
- [ ] App icon (icon.png)
- [ ] Splash icon (splash-icon.png)
- [ ] Android adaptive icon (android-icon-foreground.png)
- [ ] App name in app.config.ts
- [ ] Color palette in theme.config.js

---

## Documentation

- [ ] Architecture overview (ARCHITECTURE.md)
- [ ] API documentation
- [ ] Database schema documentation
- [ ] Edge Function documentation
- [ ] Deployment guide
- [ ] User guide / FAQ

---

## Post-Launch

- [ ] Analytics integration (PostHog)
- [ ] Push notification setup (Expo Notifications)
- [ ] Nudge scheduling (pg_cron)
- [ ] Performance monitoring
- [ ] Error tracking
- [ ] User feedback collection
